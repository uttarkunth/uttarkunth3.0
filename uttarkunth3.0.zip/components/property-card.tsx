import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { formatINR } from '@/lib/utils';
import { MapPin, Users, Sparkles, CheckCircle2 } from 'lucide-react';

export interface RoomSummary {
  id: string;
  room_name: string;
  max_guests: number;
  base_price: number;
}

export interface PropertyCardData {
  id: string;
  slug: string;
  name: string;
  village: string | null;
  district: string | null;
  state: string | null;
  description: string | null;
  amenities: string[] | any;
  photos: string[] | any;
  property_type: string;
  booking_mode?: string;
  rooms?: RoomSummary[];
}

export function PropertyCard({ property }: { property: PropertyCardData }) {
  const photoList = Array.isArray(property.photos) ? property.photos : [];
  const primaryPhoto = photoList.length > 0
    ? photoList[0]
    : 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=800&q=80';

  const lowestPrice = property.rooms && property.rooms.length > 0
    ? Math.min(...property.rooms.map(r => Number(r.base_price)))
    : 900;

  const roomName = property.rooms && property.rooms.length > 0
    ? property.rooms[0].room_name
    : 'Mountain View Room';

  const maxGuests = property.rooms && property.rooms.length > 0
    ? Math.max(...property.rooms.map(r => r.max_guests))
    : 2;

  const amenitiesList = Array.isArray(property.amenities)
    ? property.amenities.slice(0, 3)
    : [];

  return (
    <div className="group bg-white rounded-2xl overflow-hidden border border-forest/10 hover:border-forest/30 shadow-soft hover:shadow-lifted transition-all duration-300 flex flex-col">
      {/* Property Photo */}
      <Link href={`/properties/${property.slug}`} className="relative h-64 sm:h-72 w-full overflow-hidden block">
        <Image
          src={primaryPhoto}
          alt={property.name}
          fill
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/20" />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex items-center gap-1.5">
          <span className="px-2.5 py-1 bg-forest/90 backdrop-blur-md text-ivory text-xs font-semibold rounded-full shadow-sm">
            {property.property_type === 'homestay' ? 'Homestay' : 'Mountain Retreat'}
          </span>
          <span className="px-2.5 py-1 bg-white/90 backdrop-blur-md text-forest text-xs font-semibold rounded-full shadow-sm flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-ukorange" />
            Verified
          </span>
        </div>

        <div className="absolute bottom-3 left-3 right-3 text-white">
          <p className="flex items-center gap-1 text-xs font-medium drop-shadow-sm text-ivory/90">
            <MapPin className="w-3.5 h-3.5 text-ukorange flex-shrink-0" />
            <span>{property.village || 'Jari'}, {property.district || 'Kullu'}, {property.state || 'Himachal Pradesh'}</span>
          </p>
        </div>
      </Link>

      {/* Property Details */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="font-serif text-xl font-bold text-forest group-hover:text-ukorange transition-colors">
              <Link href={`/properties/${property.slug}`}>
                {property.name}
              </Link>
            </h3>
          </div>

          <p className="text-xs text-charcoal-muted line-clamp-2 leading-relaxed mb-4">
            {property.description}
          </p>

          {/* Room info & Amenities */}
          <div className="flex flex-wrap items-center gap-2 mb-4 text-xs text-charcoal-muted">
            <span className="inline-flex items-center gap-1 bg-ivory-warm px-2 py-0.5 rounded text-forest font-medium">
              <Users className="w-3.5 h-3.5 text-ukorange" />
              Up to {maxGuests} guests
            </span>
            <span className="inline-flex items-center gap-1 bg-ivory-warm px-2 py-0.5 rounded text-forest font-medium">
              {roomName}
            </span>
            {amenitiesList.map((a: string) => (
              <span key={a} className="bg-forest/5 px-2 py-0.5 rounded text-charcoal text-[11px]">
                {a}
              </span>
            ))}
          </div>
        </div>

        {/* Pricing & CTA */}
        <div className="pt-4 border-t border-forest/10 flex items-center justify-between">
          <div>
            <span className="text-[11px] text-charcoal-muted uppercase tracking-wider block">From</span>
            <div className="flex items-baseline gap-1">
              <span className="font-serif text-2xl font-bold text-forest">
                {formatINR(lowestPrice)}
              </span>
              <span className="text-xs text-charcoal-muted">/ night</span>
            </div>
          </div>

          <Link
            href={`/properties/${property.slug}`}
            className="px-4 py-2 bg-forest hover:bg-forest-hover text-white text-xs font-semibold rounded-lg shadow-sm transition-all hover:scale-105"
          >
            Request Stay
          </Link>
        </div>
      </div>
    </div>
  );
}
